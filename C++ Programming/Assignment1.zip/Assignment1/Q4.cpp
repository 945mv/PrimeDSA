#include <iostream>
using namespace std;
int main () {
    int a,b;
    cin>>a>>b;
    if (a>b) {
        cout<<"a is Greater"<<endl;
    } else {
        cout<<"b is Greater"<<endl;
    }
    return 0;
}