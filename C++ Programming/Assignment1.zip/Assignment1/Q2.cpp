#include <iostream>
using namespace std;
int main() {
    int P,R,T;
    cin>>P>>R>>T;
    double SI = P*R*T/100;
    cout<<SI;
    return 0;
}